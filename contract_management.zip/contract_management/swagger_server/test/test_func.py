from swagger_server import func

def test_answer():
    assert func.inc(3) == 4
