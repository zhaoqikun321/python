from swagger_server.server.dao import team_dao
from swagger_server.sdk.service_vo.team_vo import TeamVo
from swagger_server.server.entity import models
from swagger_server.common.utils.json_util import dict2obj
import mock


class Session:
    def __init__(self):
        self.team = None

    def add(self, team):
        self.team = team

    def flush(self):
        pass


session = Session()


@mock.patch('swagger_server.server.entity.db_base.get_session', return_value=session)
def test_add_contract(mock_get_session):
    team_vo = TeamVo()
    team_vo.name = "运维组1"
    team_vo.des = "运维组1"
    team_vo.display_order = "high"
    # print("#########team_vo: %s" %team_vo.__dict__)

    team = team_dao.Team_Dao()
    contract_id = team.insert_team(team_vo)
    # print("#########team: %s" %session.team.__dict__)

    assert team_vo.name == session.team.name
    assert team_vo.des == session.team.des
    assert team_vo.display_order == session.team.display_order









