import ast

import connexion
import json
from swagger_server.server.service import teamInfo_service
from swagger_server.sdk.service_vo.team_vo import TeamVo
from swagger_server.common.utils.json_util import dict2obj
import logging
import traceback
from swagger_server.server.entity.models import session
from swagger_server.sdk.common.platform_result import SucessJSONResponse, FailureJSONResponse

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# 添加运维组
def add_team(body):  # noqa: E501
    """Add a new Team

     # noqa: E501

    :param body: Created team
    :type body: dict | bytes

    :rtype: None
    """
    try:
        if connexion.request.is_json:
            body = connexion.request.get_json()
        team_vo = dict2obj(body, TeamVo)
        dict_data=teamInfo_service.add_team(team_vo)
        session.commit()
        session.close()
        return SucessJSONResponse(dict_data)
    except Exception as e:
        session.rollback()
        session.close()
        logger.error("error message：%s " % e.args)
        traceback.print_exc()
        return FailureJSONResponse(e)



# 编辑运维组,默认值查询
def get_team_by_id(Id):  # noqa: E501
    """Find team by ID

    Returns a single team # noqa: E501

    :param Id: ID of team to return
    :type Id: int

    :rtype: Team
    """
    try:
        dict_data = teamInfo_service.query_teamVo_byId(Id)
        session.commit()
        session.close()
        return SucessJSONResponse(dict_data)
    except Exception as e:
        session.rollback()
        session.close()
        logger.error("error message：%s " % e.args)
        traceback.print_exc()
        return FailureJSONResponse(e)



# 编辑运维组之后提交数据
def update_team(body):  # noqa: E501
    """Update an existing team

     # noqa: E501

    :param body: Update team object
    :type body: dict | bytes

    :rtype: None
    """
    try:
        if connexion.request.is_json:
            body = connexion.request.get_json()
        team_vo = dict2obj(body, TeamVo)
        teamInfo_service.update_team(team_vo)
        session.commit()
        session.close()
        return SucessJSONResponse(data=None)
    except Exception as e:
        session.rollback()
        session.close()
        logger.error("error message：%s " % e.args)
        traceback.print_exc()
        return FailureJSONResponse(e)



# 级联删除运维组，运维组关联的角色及成员
def delete_team(Id):  # noqa: E501
    """Deletes a team

     # noqa: E501

    :param Id: Team id to delete
    :type Id: int

    :rtype: None
    """
    try:
        teamInfo_service.remove_team_byId(Id)
        session.commit()
        session.close()
        return SucessJSONResponse(data=None)
    except Exception as e:
        session.rollback()
        session.close()
        logger.error("error message：%s " % e.args)
        traceback.print_exc()
        return FailureJSONResponse(e)



# 获取运维组列表接口
def query_team_list_info():
    try:
        body = connexion.request.get_json()
        dict_data = teamInfo_service.query_team_list(body)
        session.commit()
        session.close()
        return SucessJSONResponse(dict_data)
    except Exception as e:
        session.rollback()
        session.close()
        logger.error("error message：%s " % e.args)
        traceback.print_exc()
        return FailureJSONResponse(e)



# 运维组管理页，运维组显示信息
def list_teamInfo(Id):
    try:
        dict_data=teamInfo_service.query_teamInfo_byId(Id)
        session.commit()
        session.close()
        return SucessJSONResponse(dict_data)
    except Exception as e:
        session.rollback()
        session.close()
        logger.error("error message：%s " % e.args)
        traceback.print_exc()
        return FailureJSONResponse(e)



# 点击运维组，运维组人员信息分页查询
def list_teammemberInfo(Id):
    try:
        dict_data = teamInfo_service.query_teammemberInfo_byTeamId(Id)
        session.commit()
        session.close()
        return SucessJSONResponse(dict_data)
    except Exception as e:
        session.rollback()
        session.close()
        logger.error("error message：%s " % e.args)
        traceback.print_exc()
        return FailureJSONResponse(e)



# 级联添加角色
def add_role(body):
    try:
        if connexion.request.is_json:
            body = connexion.request.get_json()
        team_id = body["team_id"]
        role_name = body["role_name"]
        teamInfo_service.add_role(team_id, role_name)
        session.commit()
        session.close()
        return SucessJSONResponse(data=None)
    except Exception as e:
        session.rollback()
        session.close()
        logger.error("error message：%s " % e.args)
        traceback.print_exc()
        return FailureJSONResponse(e)



# 更新角色
def update_role(body):
    try:
        if connexion.request.is_json:
            body = connexion.request.get_json()
        team_id= body["team_id"]
        role_id = body["role_id"]
        role_name = body["role_name"]
        teamInfo_service.update_role(team_id,role_id, role_name)
        session.commit()
        session.close()
        return SucessJSONResponse(data=None)
    except Exception as e:
        session.rollback()
        session.close()
        logger.error("error message：%s " % e.args)
        traceback.print_exc()
        return FailureJSONResponse(e)



# 级联删除角色
def delete_role(Id):
    try:
        teamInfo_service.delete_role_byId(Id)
        session.commit()
        session.close()
        return SucessJSONResponse(data=None)
    except Exception as e:
        session.rollback()
        session.close()
        logger.error("error message：%s " % e.args)
        traceback.print_exc()
        return FailureJSONResponse(e)



# 点击角色，运维组人员信息分页查询
def list_teammember_ofRole(role_id):
    try:
        dict_data = teamInfo_service.query_teammember_byRoleId(role_id)
        session.commit()
        session.close()
        return SucessJSONResponse(dict_data)
    except Exception as e:
        session.rollback()
        session.close()
        logger.error("error message：%s " % e.args)
        traceback.print_exc()
        return FailureJSONResponse(e)


# 管理人员,默认值查询
def query_teammember_ofDefault(role_id):
    try:
        dict_data = teamInfo_service.query_teammember_ofDefault(role_id)
        session.commit()
        session.close()
        return SucessJSONResponse(dict_data)
    except Exception as e:
        session.rollback()
        session.close()
        logger.error("error message：%s " % e.args)
        traceback.print_exc()
        return FailureJSONResponse(e)


# 管理人员,更新人员到角色
def add_teammember_ofRole(body):
    try:
        if connexion.request.is_json:
            body = connexion.request.get_json()
        role_id = body["role_id"]
        user_idList = body["user_idList"]
        teamInfo_service.add_teammember_ofRole(role_id, user_idList)
        session.commit()
        session.close()
        return SucessJSONResponse(None)
    except Exception as e:
        session.rollback()
        session.close()
        logger.error("error message：%s " % e.args)
        traceback.print_exc()
        return FailureJSONResponse(e)


# 添加运维队伍与资源的关系
def add_teamassets(body):
    try:
        if connexion.request.is_json:
            body = connexion.request.get_json()
        teamInfo_service.add_teamassets(body)
        session.commit()
        session.close()
        return SucessJSONResponse(data=None)
    except Exception as e:
        session.rollback()
        session.close()
        logger.error("error message：%s " % e.args)
        traceback.print_exc()
        return FailureJSONResponse(e)


# 查询运维队伍对应的资源关系
def query_teamassets(Id):
    try:
        data = teamInfo_service.query_teamassets_byTeamId(Id)
        session.commit()
        session.close()
        return SucessJSONResponse(data)
    except Exception as e:
        session.rollback()
        session.close()
        logger.error("error message：%s " % e.args)
        traceback.print_exc()
        return FailureJSONResponse(e)
