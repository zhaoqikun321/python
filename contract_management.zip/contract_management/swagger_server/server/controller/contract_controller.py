import logging
import os
import traceback

import connexion

from swagger_server.common.constant.common_constant import ConmonConstant
from swagger_server.common.exception import business_exception as exception
from swagger_server.sdk.common.platform_result import SucessJSONResponse, FailureJSONResponse
from swagger_server.server.service import contractInfo_service

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def add_contract(body):  # noqa: E501
    """Add a new Contract

     # noqa: E501

    :param body: Created contract
    :type body: dict | bytes

    :rtype: None
    """
    try:
        if connexion.request.is_json:
            body = connexion.request.get_json()  # noqa: E501
            logger.info("input data %s" % body)
        else:
            msg = "输入数据不是json格式!"
            logger.error(msg)
            raise exception.TypeError(msg)
        contractInfo_service.add_contract(body)
    except Exception as e:
        traceback.print_exc()
        return FailureJSONResponse(e)
    else:
        return SucessJSONResponse(data=None)


def delete_contract(Id):  # noqa: E501
    """Deletes a contract

     # noqa: E501

    :param Id: Contract id to delete
    :type Id: int

    :rtype: None
    """
    try:
        contractInfo_service.remove_contract_by_id(Id)
    except Exception as e:
        traceback.print_exc()
        return FailureJSONResponse(e)
    else:
        return SucessJSONResponse(data=None)


def delete_contracts(aa):  # noqa: E501
    """Deletes contracts

     # noqa: E501

    :param Id_list: Contract id list to delete
    :type Id_list: List[int]

    :rtype: None
    """
    try:
        if connexion.request.is_json:
            body = connexion.request.get_json()  # noqa: E501
            logger.info("input data %s" % body)
        else:
            msg = "输入数据不是json格式!"
            logger.error(msg)
            raise exception.TypeError(msg)
        contractInfo_service.remove_contracts_by_ids(body['Id_list'])
    except Exception as e:
        traceback.print_exc()
        return FailureJSONResponse(e)
    else:
        return SucessJSONResponse(data=None)

def get_contract_by_id(Id):  # noqa: E501
    """Find contract by ID

    Returns a single contract # noqa: E501

    :param Id: ID of contract to return
    :type Id: int

    :rtype: Contract
    """
    try:
        contract_data = contractInfo_service.query_contract_by_id(Id)
    except Exception as e:
        traceback.print_exc()
        return FailureJSONResponse(e)
    else:
        return SucessJSONResponse(contract_data)


def list_contracts():  # noqa: E501
    """list all contracts

    Returns all contract list # noqa: E501


    :rtype: Contracts
    """
    try:
        contract_data = contractInfo_service.query_contract_list()
    except Exception as e:
        traceback.print_exc()
        return FailureJSONResponse(e)
    else:
        #import pdb;pdb.set_trace()
        return SucessJSONResponse(contract_data)


def update_contract(body):  # noqa: E501
    """Update an existing contract

     # noqa: E501

    :param body: Update contract object
    :type body: dict | bytes

    :rtype: None
    """
    try:
        if connexion.request.is_json:
            body = connexion.request.get_json()  # noqa: E501
            logger.info("input data %s" % body)
        else:
            msg = "输入数据不是json格式!"
            logger.error(msg)
            raise exception.TypeError(msg)
        contractInfo_service.update_contract(body)
    except Exception as e:
        traceback.print_exc()
        return FailureJSONResponse(e)
    else:
        return SucessJSONResponse(data=None)


def find_contract_by_filters(page_size=10, page_no=1, signed_start_date=None, signed_end_date=None, name=None):  # noqa: E501
    """get contract by filters

    Returns contract by filters # noqa: E501

    :param signed_start_date: signed start date of contract that need to be considered for filter
    :type signed_start_date: string
    :param signed_end_date: signed end date of contract that need to be considered for filter
    :type signed_end_date: string
    :param name: name of contract that need to be considered for filter
    :type name: string

    :rtype: Contracts
    """
    try:
        contract_data = contractInfo_service.query_contract_list(page_size=page_size, page_no=page_no, signed_start_date=signed_start_date, signed_end_date=signed_end_date, name=name)
    except Exception as e:
        traceback.print_exc()
        return FailureJSONResponse(e)
    else:
        return SucessJSONResponse(contract_data)


def find_contract_statistic_by_filters(signed_start_date=None, signed_end_date=None, name=None):  # noqa: E501
    """get contract by filters

    Returns contract by filters # noqa: E501

    :param signed_start_date: signed start date of contract that need to be considered for filter
    :type signed_start_date: string
    :param signed_end_date: signed end date of contract that need to be considered for filter
    :type signed_end_date: string
    :param name: name of contract that need to be considered for filter
    :type name: string

    :rtype: Contracts
    """
    try:
        contract_data = contractInfo_service.query_contract_statistic(signed_start_date=signed_start_date, signed_end_date=signed_end_date, name=name)
    except Exception as e:
        traceback.print_exc()
        return FailureJSONResponse(e)
    else:
        return SucessJSONResponse(contract_data)


def import_contractfile_to_db(contract_file):  # noqa: E501
    """import contract file to db

     # noqa: E501

    :param contract_file: contract file
    :type contract_file: string

    :rtype: None
    """
    try:
        file_dir = ConmonConstant.FILE_DIR
        contract_file_path = '%s/%s' % (file_dir, contract_file)
        if not os.path.isfile(contract_file_path):
            msg = "contract file %s not found!" % contract_file_path
            logger.error(msg)
            raise exception.NotFound(msg)
        contractInfo_service.import_contractfile_to_db(contract_file_path)
    except Exception as e:
        traceback.print_exc()
        return FailureJSONResponse(e)
    else:
        return SucessJSONResponse(data=None)


def export_db_to_contractfile(Id_list):  # noqa: E501
    """generate contract file from contract db

     # noqa: E501

    :param Id_list: Contract id list to generate contract file
    :type Id_list: List[int]

    :rtype: None
    """
    try:
        contractInfo_service.export_db_to_contractfile(Id_list)
    except Exception as e:
        traceback.print_exc()
        return FailureJSONResponse(e)
    else:
        return SucessJSONResponse(data=None)


def upload_contract():
    try:
        contractInfo_service.upload_to_host()
        return SucessJSONResponse(None)
    except Exception as e:
        traceback.print_exc()
        return FailureJSONResponse(e)


def get_contract_templet():
    try:
        response = contractInfo_service.download_contract_templet()
    except Exception as e:
        traceback.print_exc()
        return FailureJSONResponse(e)
    else:
        return response
