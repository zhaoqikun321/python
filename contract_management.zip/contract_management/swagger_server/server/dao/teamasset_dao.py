from swagger_server.server.entity import models

session = models.session


def insert_teamAssets(team_assets):
    session.add_all(team_assets)

def delete_teamAsset_byTeamId(team_id):
    session.query(models.Teamasset).filter(models.Teamasset.team_id == team_id).delete()

def select_teamAssets_byTeamId(team_id):
    team_assets = session.query(models.Teamasset).filter(models.Teamasset.team_id == team_id).all()
    return team_assets