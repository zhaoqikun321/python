from sqlalchemy import and_

from swagger_server.server.entity import models

session = models.session


def insert_teammembers(teammembers):
    session.add_all(teammembers)


def insert_teammember(teammember):
    session.add(teammember)


def delete_teammember_byTeamId(team_id):
    session.query(models.Teammember).filter(models.Teammember.team_id == team_id).delete()


def delete_teammember_byUserId(user_id):
    session.query(models.Teammember).filter(models.Teammember.user_id == user_id).delete()


def delete_teammember_byRoleId(role_id):
    session.query(models.Teammember).filter(models.Teammember.role_id == role_id).delete()


def select_teammember_page(team_id, page_size, page_no):
    teammembers = session.query(models.Teammember).filter(
        and_(models.Teammember.team_id == team_id, models.Teammember.user_id != None)).order_by(
        models.Teammember.display_order).limit(page_size).offset((page_no - 1) * page_size)
    return teammembers


def select_teammemberOfrole_page(role_id, page_size, page_no):
    teammembers = session.query(models.Teammember).filter(
        and_(models.Teammember.role_id == role_id, models.Teammember.user_id != None)).limit(page_size).offset(
        (page_no - 1) * page_size)
    return teammembers


def select_teammember_byTeamId(team_id):
    teammembers = session.query(models.Teammember).filter(models.Teammember.team_id == team_id).order_by(
        models.Teammember.display_order).all()
    return teammembers


def select_teammember_byRoleId(role_id):
    teammembers = session.query(models.Teammember).filter(models.Teammember.role_id == role_id).all()
    return teammembers


def update_teammember_byRoleId(role_id, role_name):
    dict_data = dict()
    dict_data['role_id'] = role_id
    dict_data['role_name'] = role_name
    session.query(models.Teammember).filter(models.Teammember.role_id == role_id).update(dict_data)


def update_teammember_byTeamId(team_id, team_name):
    dict_data = dict()
    dict_data['team_id'] = team_id
    dict_data['team_name'] = team_name
    session.query(models.Teammember).filter(models.Teammember.team_id == team_id).update(dict_data)


def update_teammember_byUserId(user_id):
    dict_data = dict()
    dict_data['user_id'] = None
    session.query(models.Teammember).filter(models.Teammember.user_id == user_id).update(dict_data)
    session.commit()
    session.close()


def select_teammember_byTeamIdAndRoleName(team_id, role_name):
    teammembers = session.query(models.Teammember).filter(
        and_(models.Teammember.team_id == team_id, models.Teammember.role_name == role_name)).all()
    return teammembers
