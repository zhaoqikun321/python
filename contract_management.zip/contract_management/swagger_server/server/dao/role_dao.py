from swagger_server.server.entity import models

session = models.session


def select_role_byId(id):
    role = session.query(models.Role).filter(models.Role.id == id).first()
    return role

def select_role_byUserId(id):
    role = session.query(models.Role).filter(models.Role.id == id).first()
    return role


def insert_role(role_name, display_order):
    role_ref = models.Role()
    role_ref.name = role_name
    role_ref.display_order=display_order
    session.add(role_ref)
    session.flush()
    return role_ref.id


def delete_role_byId(id):
    session.query(models.Role).filter(models.Role.id == id).delete()


def update_role(role_id,role_name):
    dict_data=dict()
    dict_data['id']=role_id
    dict_data['name']=role_name
    session.query(models.Role).filter(models.Role.id == role_id).update(dict_data)
