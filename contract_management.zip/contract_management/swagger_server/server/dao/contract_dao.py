from swagger_server.server.entity import models
import logging
from swagger_server.common.exception import business_exception as exception


logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

session = models.session

asset_type_dict = {0: 'resource', 1: 'cluster', 2: 'system'}
user_type_dict = {0: 'technical_support', 1: 'business_support', 2: 'resident_support'}

def add_contract(contract):
    contract_ref = models.Contract()
    contract_ref.name = contract['name']
    contract_ref.contract_code = contract['contract_code']
    contract_ref.type = contract['type']
    contract_ref.owner_company = contract['owner_company']
    contract_ref.owner = contract['owner']
    contract_ref.owner_signer = contract['owner_signer']
    contract_ref.owner_bank = contract['owner_bank']
    contract_ref.owner_bank_account = contract['owner_bank_account']
    contract_ref.contractor_company = contract['contractor_company']
    contract_ref.contractor_signer = contract['contractor_signer']
    contract_ref.contractor_bank = contract['contractor_bank']
    contract_ref.contractor_bank_account = contract['contractor_bank_account']
    contract_ref.contractor = contract['contractor']
    contract_ref.amount = contract['amount']
    contract_ref.payment_ratio = contract['payment_ratio']
    contract_ref.signed_date = contract['signed_date']
    contract_ref.start_date = contract['start_date']
    contract_ref.end_date = contract['end_date']
    session.add(contract_ref)
    session.flush()
    contract_id = contract_ref.id
    return contract_id


def add_contract_asset(contract_id, asset_ids, asset_type):
    contract_assets = []
    msg = "add %s assets..." % asset_type_dict[asset_type]
    logger.info(msg)
    for asset_id in asset_ids:
        contract_asset = models.Contractasset()
        if asset_type == 0:
            asset_category = asset_id['category']
            asset_id = asset_id['id']
            contract_asset.asset_category = asset_category
        contract_asset.contract_id = contract_id
        contract_asset.asset_id = asset_id
        contract_asset.asset_type = asset_type
        contract_assets.append(contract_asset)
        session.add_all(contract_assets)

def add_contract_member(contract_id, user_id_list, user_type):
    contract_members = []
    msg = "add %s members..." % user_type_dict[user_type]
    logger.info(msg)
    for user_id in user_id_list:
        contract_member = models.Contractmember()
        contract_member.contract_id = contract_id
        contract_member.user_id = user_id
        contract_member.user_type = user_type
        contract_members.append(contract_member)
    session.add_all(contract_members)

def delete_contract_by_id(id):
    contract = session.query(models.Contract).filter(models.Contract.id == id).first()
    if contract:
        session.delete(contract)
    else:
        msg = "合同ID %s 未找到" % id
        logger.error(msg)
        raise exception.NotFound(msg)

def select_contract_by_id(id):
    contract = session.query(models.Contract).filter(models.Contract.id == id).first()
    if contract:
        return contract
    else:
        msg = "合同ID %s 未找到" % id
        logger.error(msg)
        raise exception.NotFound(msg)

def get_contract_asset(contract_id, asset_type):
    asset_id_list = []
    msg = "get %s assets..." % asset_type_dict[asset_type]
    logger.info(msg)
    contract_assets = session.query(models.Contractasset).filter(models.Contractasset.contract_id == contract_id).filter(models.Contractasset.asset_type == asset_type).all()
    if asset_type == 0:
        for contract_asset in contract_assets:
            asset_id_list.append({'id':contract_asset.asset_id, 'category': contract_asset.asset_category})
    else:
        for contract_asset in contract_assets:
            asset_id_list.append(contract_asset.asset_id)
    return asset_id_list


def get_contract_member(contract_id, user_type):
    user_id_list = []
    msg = "get %s members..." % user_type_dict[user_type]
    logger.info(msg)
    contract_members = session.query(models.Contractmember).filter(models.Contractmember.contract_id == contract_id).filter(models.Contractmember.user_type == user_type).all()
    for contract_member in contract_members:
        user_id_list.append(contract_member.user_id)
    return user_id_list


def select_contract_list(page_size, page_no, signed_start_date, signed_end_date, name):
    aa = session.query(models.Contract)
    if name:
        aa = aa.filter(models.Contract.name.like('%' + name + '%'))
    if signed_start_date:
        aa = aa.filter(models.Contract.signed_date != None).filter(models.Contract.signed_date != '').filter(models.Contract.signed_date >= signed_start_date)
    if signed_end_date:
        aa = aa.filter(models.Contract.signed_date != None).filter(models.Contract.signed_date != '').filter(models.Contract.signed_date <= signed_end_date)
    contracts = aa.limit(page_size).offset((page_no-1)*page_size)
    return contracts


def select_all_contract_list(signed_start_date, signed_end_date, name):
    aa = session.query(models.Contract)
    if name:
        aa = aa.filter(models.Contract.name.like('%' + name + '%'))
    if signed_start_date:
        aa = aa.filter(models.Contract.signed_date != None).filter(models.Contract.signed_date != '').filter(models.Contract.signed_date >= signed_start_date)
    if signed_end_date:
        aa = aa.filter(models.Contract.signed_date != None).filter(models.Contract.signed_date != '').filter(models.Contract.signed_date <= signed_end_date)
    contracts = aa.all()
    return contracts


def update_contract(contract):
    contract_ref = session.query(models.Contract).filter(models.Contract.id == contract['id']).first()
    if contract_ref:
        contract_ref.name = contract['name']
        contract_ref.contract_code = contract['contract_code']
        contract_ref.type = contract['type']
        contract_ref.owner_company = contract['owner_company']
        contract_ref.owner = contract['owner']
        contract_ref.owner_signer = contract['owner_signer']
        contract_ref.owner_bank = contract['owner_bank']
        contract_ref.owner_bank_account = contract['owner_bank_account']
        contract_ref.contractor_company = contract['contractor_company']
        contract_ref.contractor_signer = contract['contractor_signer']
        contract_ref.contractor_bank = contract['contractor_bank']
        contract_ref.contractor_bank_account = contract['contractor_bank_account']
        contract_ref.contractor = contract['contractor']
        contract_ref.amount = contract['amount']
        contract_ref.payment_ratio = contract['payment_ratio']
        contract_ref.signed_date = contract['signed_date']
        contract_ref.start_date = contract['start_date']
        contract_ref.end_date = contract['end_date']
    else:
        msg = "合同ID %s 未找到" % contract['id']
        logger.error(msg)
        raise exception.NotFound(msg)


def update_contract_asset(contract_id, asset_ids, asset_type):
    contract_assets = session.query(models.Contractasset).filter(
        models.Contractasset.contract_id == contract_id).filter(models.Contractasset.asset_type == asset_type).all()
    if asset_type == 0:
        asset_id_dict = {}
        for asset_id in asset_ids:
            asset_id_dict[asset_id['id']] = asset_id['category']
        origin_asset_ids = {}
        for contract_asset in contract_assets:
            origin_asset_ids[contract_asset.asset_id] = contract_asset.asset_category
        delete_assets_dict = dict(origin_asset_ids.items() -  asset_id_dict.items())
        add_assets_dict = dict(asset_id_dict.items() -  origin_asset_ids.items())
        delete_assets = []
        add_assets = []
        for k, v in delete_assets_dict.items():
            delete_assets.append({'id': k, 'category': v})
        for k, v in add_assets_dict.items():
            add_assets.append({'id': k, 'category': v})
    else:
        origin_asset_ids = []
        for contract_asset in contract_assets:
            origin_asset_ids.append(contract_asset.asset_id)
        delete_assets = list(set(origin_asset_ids).difference(set(asset_ids)))
        add_assets = list(set(asset_ids).difference(set(origin_asset_ids)))
    delete_contract_asset(contract_id, delete_assets, asset_type)
    add_contract_asset(contract_id, add_assets, asset_type)

def delete_contract_asset(contract_id, asset_ids, asset_type):
    if asset_type == 0:
        for asset_id in asset_ids:
            session.query(models.Contractasset).filter(models.Contractasset.contract_id == contract_id).filter(models.Contractasset.asset_id == asset_id['id']).filter(models.Contractasset.asset_category == asset_id['category']).delete()
    else:
        for asset_id in asset_ids:
            session.query(models.Contractasset).filter(models.Contractasset.contract_id == contract_id).filter(models.Contractasset.asset_id == asset_id).delete()

def update_contract_member(contract_id, user_id_list, user_type):
    contract_members = session.query(models.Contractmember).filter(models.Contractmember.contract_id == contract_id).filter(models.Contractmember.user_type == user_type).all()
    origin_user_id_list = []
    for contract_member in contract_members:
        origin_user_id_list.append(contract_member.user_id)
    delete_users = list(set(origin_user_id_list).difference(set(user_id_list)))
    delete_contract_member(contract_id, delete_users, user_type)
    add_users = list(set(user_id_list).difference(set(origin_user_id_list)))
    add_contract_member(contract_id, add_users, user_type)

def  delete_contract_member(contract_id, user_id_list, user_type):
    for user_id in user_id_list:
        session.query(models.Contractmember).filter(models.Contractmember.contract_id == contract_id).filter(models.Contractmember.user_id == user_id).filter(models.Contractmember.user_type == user_type).delete()

def select_contract_by_name(name):
    contracts = session.query(models.Contract).filter(models.Contract.name == name).first()
    return contracts

def select_contract_by_code(contract_code):
    contracts = session.query(models.Contract).filter(models.Contract.contract_code == contract_code).first()
    return contracts
