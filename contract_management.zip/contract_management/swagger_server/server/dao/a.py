from swagger_server.server.entity import models
from swagger_server.server.entity import db_base
from swagger_server.common.utils.json_util import obj2dict



class Team_Dao():
    def __init__():
        session = db_base.get_session()

	def insert_team(team_vo):
	    team_ref = models.Team()
	    team_ref.name = team_vo.name
	    team_ref.des = team_vo.des
	    team_ref.display_order = team_vo.display_order
	    session.add(team_ref)
	    session.flush()
	    return team_ref.id


	def delete_team_byId(id):
	    session.query(models.Team).filter(models.Team.id == id).delete()


	def select_team_byId(id):
	    team = session.query(models.Team).filter(models.Team.id == id).first()
	    return team


	def select_team_byName(name):
	    team = session.query(models.Team).filter(models.Team.name == name).first()
	    return team


	def select_team_list(staffIdList):
	    teams = session.query(models.Team).filter(models.Teammember.user_id.in_(staffIdList)) \
		.filter(models.Team.id == models.Teammember.team_id) \
		.order_by(models.Team.display_order).distinct().all()
	    return teams


	def update_team(team):
	    dict_data = obj2dict(team)
	    del dict_data['_sa_instance_state']
	    session.query(models.Team).filter(models.Team.id == team.id).update(dict_data)


	# if __name__ == '__main__':
	#     teams=select_team_list(eval("[1001,7,3,4]"))
	#     for team in teams:
	#         print(team.id)
	#         print(team.name)



