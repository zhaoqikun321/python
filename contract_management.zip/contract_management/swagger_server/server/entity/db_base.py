# coding: utf-8
import configparser
import platform

from sqlalchemy import create_engine, Column, BigInteger, String, DECIMAL, ForeignKey, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship, scoped_session


def getSQLConfig(filename):
    cf = configparser.ConfigParser()
    cf.read(filename)
    _host = cf.get("DEFAULT", "HOSTNAME")
    _port = cf.get("DEFAULT", "PORT")
    _database = cf.get("DEFAULT", "DATABASE")
    _user = cf.get("DEFAULT", "USERNAME")
    _pwd = cf.get("DEFAULT", "PASSWORD")
    return _host, _port, _database, _user, _pwd




def get_session():
    windows_path = "D://PythonProject-2//contract_management//swagger_server//mysql//config//dbConnection.ini"
    path = "/etc/contract/dbConnection.ini"
    if (platform.system() == 'Windows'):
        HOSTNAME, PORT, DATABASE, USERNAME, PASSWORD = getSQLConfig(windows_path)
    else:
        HOSTNAME, PORT, DATABASE, USERNAME, PASSWORD = getSQLConfig(path)

    DB_URL = 'mysql+mysqlconnector://{username}:{password}@{hostname}:{port}/{database}?charset=utf8'.format(
        username=USERNAME,
        password=PASSWORD,
        hostname=HOSTNAME,
        port=PORT,
        database=DATABASE
    )

    engine = create_engine(DB_URL, max_overflow=0, pool_size=100, pool_timeout=30, pool_recycle=300)

    Base = declarative_base(engine)
    SessionFactory = sessionmaker(bind=engine)
    session = scoped_session(SessionFactory)
    return session
