# coding: utf-8
import configparser
import platform

from sqlalchemy import create_engine, Column, BigInteger, String, DECIMAL, ForeignKey, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship, scoped_session

from swagger_server.server.entity import db_base




"""
def getSQLConfig(filename):
    cf = configparser.ConfigParser()
    cf.read(filename)
    _host = cf.get("DEFAULT", "HOSTNAME")
    _port = cf.get("DEFAULT", "PORT")
    _database = cf.get("DEFAULT", "DATABASE")
    _user = cf.get("DEFAULT", "USERNAME")
    _pwd = cf.get("DEFAULT", "PASSWORD")
    return _host, _port, _database, _user, _pwd


    windows_path = "D://PythonProject-2//contract_management//swagger_server//mysql//config//dbConnection.ini"
    path = "/etc/contract/dbConnection.ini"
    if (platform.system() == 'Windows'):
        HOSTNAME, PORT, DATABASE, USERNAME, PASSWORD = getSQLConfig(windows_path)
    else:
        HOSTNAME, PORT, DATABASE, USERNAME, PASSWORD = getSQLConfig(path)

    DB_URL = 'mysql+mysqlconnector://{username}:{password}@{hostname}:{port}/{database}?charset=utf8'.format(
        username=USERNAME,
        password=PASSWORD,
        hostname=HOSTNAME,
        port=PORT,
        database=DATABASE
    )

    engine = create_engine(DB_URL, max_overflow=0, pool_size=100, pool_timeout=30, pool_recycle=300)

    Base = declarative_base(engine)
    SessionFactory = sessionmaker(bind=engine)
    session = scoped_session(SessionFactory)
"""

Base = declarative_base()


class Team(Base):
    __tablename__ = 'team'

    id = Column(BigInteger, primary_key=True)
    name = Column(String(20), info='运维团队名称')
    des = Column(String(100), info='描述')
    display_order = Column(BigInteger, info='运维组展示顺序')

    def dobule_to_dict(self):
        result = {}
        for key in self.__mapper__.c.keys():
            if getattr(self, key) is not None:
                result[key] = str(getattr(self, key))
            else:
                result[key] = getattr(self, key)
        return result


class Teamasset(Base):
    __tablename__ = 'teamasset'

    id = Column(BigInteger, primary_key=True)
    team_id = Column(BigInteger, info='运维团队id')
    asset_id = Column(BigInteger, info='资产表id')
    asset_type = Column(BigInteger, info='资产类型,0资源,1平台系统,2业务系统')
    asset_category = Column(BigInteger, info='资源中资产类型所属类目')

    def dobule_to_dict(self):
        result = {}
        for key in self.__mapper__.c.keys():
            if getattr(self, key) is not None:
                result[key] = getattr(self, key)
            else:
                result[key] = getattr(self, key)
        return result


class Teammember(Base):
    __tablename__ = 'teammember'

    id = Column(BigInteger, primary_key=True)
    team_id = Column(BigInteger, info='运维团队表id')
    role_id = Column(BigInteger, info='角色表id')
    role_name = Column(String(20), info='角色名')
    user_id = Column(BigInteger, info='用户表id')
    display_order = Column(BigInteger, info='角色展示顺序')

    def dobule_to_dict(self):
        result = {}
        for key in self.__mapper__.c.keys():
            if getattr(self, key) is not None:
                result[key] = str(getattr(self, key))
            else:
                result[key] = getattr(self, key)
        return result


class Role(Base):
    __tablename__ = 'role'

    id = Column(BigInteger, primary_key=True)
    name = Column(String(20), info='角色名')
    display_order = Column(BigInteger, info='角色展示顺序')

    def dobule_to_dict(self):
        result = {}
        for key in self.__mapper__.c.keys():
            if getattr(self, key) is not None:
                result[key] = str(getattr(self, key))
            else:
                result[key] = getattr(self, key)
        return result


class Contract(Base):
    __tablename__ = 'contract'

    id = Column(BigInteger, primary_key=True)
    contract_code = Column(String(40), info='合同编号')
    name = Column(String(40), info='合同名称')
    type = Column(String(64), info='合同类型')
    owner = Column(BigInteger, info='甲方项目经理')
    owner_company = Column(BigInteger, info='甲方单位')
    owner_signer = Column(BigInteger, info='甲方合同签署人')
    owner_bank = Column(String(40), info='甲方开户银行')
    owner_bank_account = Column(String(20), info='甲方银行账号')
    contractor = Column(BigInteger, info='乙方项目经理')
    contractor_company = Column(BigInteger, info='乙方单位')
    contractor_signer = Column(BigInteger, info='乙方合同签署人')
    contractor_bank = Column(String(40), info='乙方开户银行')
    contractor_bank_account = Column(String(20), info='乙方银行账号')
    signed_date = Column(String(64), info='签订日期')
    start_date = Column(String(64), info='起始日期')
    end_date = Column(String(64), info='结束日期')
    amount = Column(DECIMAL(8, 2), info='合同金额')
    payment_ratio = Column(Float(5, 2), info='付款比例')

    contractasset = relationship("Contractasset", cascade="delete")
    contractmember = relationship("Contractmember", cascade="delete")

    def dobule_to_dict(self):
        result = {}
        for key in self.__mapper__.c.keys():
            if getattr(self, key) is not None:
                result[key] = str(getattr(self, key))
            else:
                result[key] = getattr(self, key)
        return result


class Contractasset(Base):
    __tablename__ = 'contractasset'

    id = Column(BigInteger, primary_key=True)
    contract_id = Column(BigInteger, ForeignKey('contract.id'), info='合约表id')
    asset_id = Column(BigInteger, info='资产表id')
    asset_type = Column(BigInteger, info='资产类型,0资源,1平台系统,2业务系统')
    asset_category = Column(BigInteger, info='资源中资产类型所属类目')

    def dobule_to_dict(self):
        result = {}
        for key in self.__mapper__.c.keys():
            if getattr(self, key) is not None:
                result[key] = str(getattr(self, key))
            else:
                result[key] = getattr(self, key)
        return result


class Contractmember(Base):
    __tablename__ = 'contractmember'

    id = Column(BigInteger, primary_key=True)
    contract_id = Column(BigInteger, ForeignKey('contract.id'), info='合约表id')
    user_id = Column(BigInteger, info='用户表id')
    user_type = Column(BigInteger, info='用户类型,0,echnical_support，1,business_support，2,resident_support')

    def dobule_to_dict(self):
        result = {}
        for key in self.__mapper__.c.keys():
            if getattr(self, key) is not None:
                result[key] = str(getattr(self, key))
            else:
                result[key] = getattr(self, key)
        return result

# Base.metadata.create_all()

