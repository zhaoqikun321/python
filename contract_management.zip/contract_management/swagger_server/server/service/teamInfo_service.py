import ast
import collections
import logging

from swagger_server.common.constant.role_common import RoleConstant
from swagger_server.common.exception.business_exception import BusinessException
from swagger_server.common.exception.error_code import ErrorCode
from swagger_server.common.utils.common_util import get_timestamp, get_user_byId, get_userInfo_list, \
    get_teammember_count
from swagger_server.common.utils.json_util import obj2dict, to_json
from swagger_server.sdk.service_vo.team_vo import TeamVo, TeamInfoVo
from swagger_server.sdk.service_vo.teammember_vo import TeammemberVo
from swagger_server.server.dao import team_dao, teamasset_dao, teammember_dao, role_dao
from swagger_server.server.entity.models import Teamasset, Team, Teammember

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def add_team(team_vo):
    if team_vo.name is None:
        raise BusinessException(ErrorCode.CONTENT_IS_EMPTY)
    # 验证组名是否重复
    team = team_dao.select_team_byName(team_vo.name)
    if team is not None:
        raise BusinessException(ErrorCode.TEAM_NAME_REPEAT)
    # 设置运维组展示顺序,根据时间戳排序
    team_vo.display_order = get_timestamp()
    # 添加运维组
    team_id = team_dao.insert_team(team_vo)
    # 添加预制角色
    roleList = []
    role_id = role_dao.insert_role(RoleConstant.TEAM_LEADER, RoleConstant.DISPLAY_ONE)
    roleList.append({"role_id": role_id, "role_name": RoleConstant.TEAM_LEADER})
    role_id = role_dao.insert_role(RoleConstant.DEPUTY_TEAM_LEADER, RoleConstant.DISPLAY_TWO)
    roleList.append({"role_id": role_id, "role_name": RoleConstant.DEPUTY_TEAM_LEADER})
    role_id = role_dao.insert_role(RoleConstant.TECHNOLOGICAL_BACKBONE, RoleConstant.DISPLAY_THREE)
    roleList.append({"role_id": role_id, "role_name": RoleConstant.TECHNOLOGICAL_BACKBONE})
    role_id = role_dao.insert_role(RoleConstant.GENERAL_TECHNOLOGY_OPERATION, RoleConstant.DISPLAY_FORUE)
    roleList.append({"role_id": role_id, "role_name": RoleConstant.GENERAL_TECHNOLOGY_OPERATION})
    role_id = role_dao.insert_role(RoleConstant.BUSINESS_OPERATION, RoleConstant.DISPLAY_FIVE)
    roleList.append({"role_id": role_id, "role_name": RoleConstant.BUSINESS_OPERATION})
    # 关联运维组预制角色
    teammembers = []
    for index, role_dict in enumerate(roleList):
        teammember = Teammember()
        teammember.display_order = index + 1
        teammember.team_id = team_id
        teammember.role_id = role_dict.get("role_id")
        teammember.role_name = role_dict.get("role_name")
        teammembers.append(teammember)
    teammember_dao.insert_teammembers(teammembers)
    dict_data = {"team_id": team_id}
    return dict_data


def remove_team_byId(team_id):
    # 删除该运维组
    team_dao.delete_team_byId(team_id)
    # 删除该运维组下的角色
    teammembers = teammember_dao.select_teammember_byTeamId(team_id)
    for teammember in teammembers:
        role_dao.delete_role_byId(teammember.role_id)
    # 删除该运维组角色及成员的关联关系
    teammember_dao.delete_teammember_byTeamId(team_id)
    # 删除运维组关联对象
    teamasset_dao.delete_teamAsset_byTeamId(team_id)


def query_teamVo_byId(id):
    team = team_dao.select_team_byId(id)
    if team is None:
        raise BusinessException(ErrorCode.TEAM_IS_EMPTY)
    team_vo = TeamVo()
    team_vo.id = team.id
    team_vo.name = team.name
    team_vo.des = team.des
    dict_data = obj2dict(team_vo)
    return dict_data


# 点击运维组管理，运维组显示信息
def query_teamInfo_byId(Id):
    # 获取运维组人数
    user_num = get_teammember_count(Id)
    team = team_dao.select_team_byId(Id)
    if team is None:
        raise BusinessException(ErrorCode.TEAM_IS_EMPTY)
    teammembers = teammember_dao.select_teammember_byTeamId(Id)
    team_userNum = user_num
    teamInfo_vo = TeamInfoVo()
    teamInfo_vo.id = team.id
    teamInfo_vo.des = team.des
    teamInfo_vo.team_userNum = team_userNum
    # 组长人员id,第一个角色对应的user_id
    user_id = teammembers[0].user_id
    if user_id is None:
        dict_data = obj2dict(teamInfo_vo)
        return dict_data
    # 调用中电接口获取user_name
    user_dict = get_user_byId(user_id)
    if user_dict.get("success") == 0 and user_dict.get("message").get("errorCode") == "310005":
        dict_data = obj2dict(teamInfo_vo)
        logger.error(user_dict.get("message"))
        teammember_dao.update_teammember_byUserId(user_id)
        return dict_data
    if user_dict.get("success") == 0:
        raise BusinessException(ErrorCode.REQUEST_EXTERNAL_INTERFACE_FAILED)
    user_name = user_dict["data"]["name"]
    user_email = user_dict.get("data").get("email")
    user_tel = user_dict.get("data").get("telephone")
    teamInfo_vo.user_name = user_name
    teamInfo_vo.email = user_email
    teamInfo_vo.tel = user_tel
    dict_data = obj2dict(teamInfo_vo)
    return dict_data


# 运维组人员信息
def query_teammemberInfo_byTeamId(Id):
    dict_data = dict()
    # 获取组内人员总数
    teammembers = teammember_dao.select_teammember_byTeamId(Id);
    # 获取user_idList
    user_idList = []
    for teammember in teammembers:
        if teammember.user_id is not None:
            user_idList.append(teammember.user_id)
    if len(user_idList) == 0:
        dict_data["teammemberVoList"] = []
        return dict_data
    # 调用中电接口获取用户列表数据
    resp_dict = get_userInfo_list(user_idList)
    if resp_dict.get("success") == 0:
        logger.error(resp_dict.get("message"))
        raise BusinessException(ErrorCode.REQUEST_EXTERNAL_INTERFACE_FAILED)
    user_list = resp_dict["data"]["result"]
    teammemberVo_list = []
    for teammember in teammembers:
        for user in user_list:
            if teammember.user_id == user["staffId"]:
                teammemberVo = TeammemberVo()
                teammemberVo.role_name = teammember.role_name
                teammemberVo.user_name = user["name"]
                teammemberVo.email = user.get("email")
                teammemberVo.tel = user.get("telephone")
                teammemberVo.department = user.get("fullOrganizationName")
                teammemberVo_dict = obj2dict(teammemberVo)
                teammemberVo_list.append(teammemberVo_dict)
                break
    dict_data["teammemberVoList"] = teammemberVo_list
    return dict_data


def query_teammember_byRoleId(role_id):
    dict_data = dict()
    teammembers = teammember_dao.select_teammember_byRoleId(role_id);
    # 获取user_idList
    user_idList = []
    for teammember in teammembers:
        if teammember.user_id is not None:
            user_idList.append(teammember.user_id)
    if len(user_idList) == 0:
        dict_data["teammemberVoList"] = []
        return dict_data
    # 调用中电接口获取用户列表数据
    resp_dict = get_userInfo_list(user_idList)
    if resp_dict.get("success") == 0:
        logger.error(resp_dict.get("message"))
        raise BusinessException(ErrorCode.REQUEST_EXTERNAL_INTERFACE_FAILED)
    user_list = resp_dict["data"]["result"]
    teammemberVo_list = []
    for teammember in teammembers:
        for user in user_list:
            if teammember.user_id == user["staffId"]:
                teammemberVo = TeammemberVo()
                teammemberVo.user_name = user["name"]
                teammemberVo.email = user.get("email")
                teammemberVo.tel = user.get("telephone")
                teammemberVo.department = user.get("fullOrganizationName")
                teammemberVo_dict = obj2dict(teammemberVo)
                teammemberVo_list.append(teammemberVo_dict)
                break
    dict_data["teammemberVoList"] = teammemberVo_list
    return dict_data


def query_teammember_ofDefault(role_id):
    # 查询teammember数据集合
    teammembers = teammember_dao.select_teammember_byRoleId(role_id)
    user_idList = []
    for teammember in teammembers:
        user_idList.append(teammember.user_id)
    dict_data = dict()
    if user_idList is not None:
        dict_data["user_idList"] = user_idList
    return dict_data


# 运维组管理页，运维组列表
def query_team_list(body):
    data_dict = dict()
    staffIdList=body.get("staffIdList")
    teams = team_dao.select_team_list(staffIdList)
    if teams is None:
        return data_dict
    team_list = []
    for team in teams:
        team_dict = dict()
        team_dict["team_id"] = team.id
        team_dict["team_name"] = team.name
        teammembers = teammember_dao.select_teammember_byTeamId(team.id)
        role_dict = collections.OrderedDict()
        for teammember in teammembers:
            role_dict[teammember.role_id] = teammember.role_name
        role_list = []
        for key in role_dict:
            temp_dict = dict()
            temp_dict[key] = role_dict.get(key)
            role_list.append(temp_dict)
        team_dict["role_list"] = role_list
        team_list.append(team_dict)
    data_dict["team_list"] = team_list
    return data_dict


def update_team(team_vo):
    if team_vo.name is None:
        raise BusinessException(ErrorCode.CONTENT_IS_EMPTY)
    # 验证组名是否重复
    team = team_dao.select_team_byName(team_vo.name)
    if team is not None and team_vo.id != team.id:
        raise BusinessException(ErrorCode.TEAM_NAME_REPEAT)
    # TeamVo转Team
    team = Team()
    team.id = team_vo.id
    team.name = team_vo.name
    team.des = team_vo.des
    # 更新Team表
    team_dao.update_team(team)


def add_role(team_id, role_name):
    if role_name is None:
        raise BusinessException(ErrorCode.ROLENAME_IS_EMPTY)
    # 验证组内角色名是否重复
    teammembers = teammember_dao.select_teammember_byTeamIdAndRoleName(team_id, role_name)
    if len(teammembers) != 0:
        raise BusinessException(ErrorCode.ROLE_NAME_REPEAT)
    # 添加角色
    display_order = get_timestamp()
    role_id = role_dao.insert_role(role_name, display_order)
    # 添加运维队伍与角色的关系
    teammember = Teammember()
    teammember.display_order = display_order
    teammember.team_id = team_id
    teammember.role_id = role_id
    teammember.role_name = role_name
    teammember_dao.insert_teammember(teammember)


def update_role(team_id, role_id, role_name):
    if role_name is None:
        raise BusinessException(ErrorCode.ROLENAME_IS_EMPTY)
    # 验证组内角色名是否重复
    teammembers = teammember_dao.select_teammember_byTeamIdAndRoleName(team_id, role_name)
    if len(teammembers) != 0 and int(role_id) != teammembers[0].role_id:
        raise BusinessException(ErrorCode.ROLE_NAME_REPEAT)
    # 更新角色
    role_dao.update_role(role_id, role_name)
    # 更新teammeber表的role_name
    teammember_dao.update_teammember_byRoleId(role_id, role_name)


def delete_role_byId(role_id):
    # 删除角色
    role_dao.delete_role_byId(role_id)
    # 删除角色与运维队伍及用户的关联关系
    teammember_dao.delete_teammember_byRoleId(role_id)


def add_teammember_ofRole(role_id, user_idList):
    # 查询角色所属运维组
    teammembers = teammember_dao.select_teammember_byRoleId(role_id)
    team_id = teammembers[0].team_id
    # 删除角色与用户的关系
    teammember_dao.delete_teammember_byRoleId(role_id)
    # 获取展示顺序
    role = role_dao.select_role_byId(role_id)
    display_order = role.display_order
    # 删除所有人时,保留运维组角色
    if len(user_idList) == 0:
        teammember = Teammember()
        teammember.team_id = team_id
        teammember.role_id = role_id
        teammember.role_name = role.name
        teammember.display_order = display_order
        teammember_dao.insert_teammember(teammember)
        return
    # 验证待添加人员是否已在运维组中
    teammembers = teammember_dao.select_teammember_byTeamId(team_id)
    if (len(teammembers) != 0):
        for teammember in teammembers:
            if teammember.user_id != None and teammember.user_id in user_idList:
                raise BusinessException(ErrorCode.USER_IS_EXISTS)
    # user_idList不为空时,添加运维组,角色,用户的关系
    teammembers = []
    for user_id in user_idList:
        teammember = Teammember()
        teammember.display_order = display_order
        teammember.team_id = team_id
        teammember.role_id = role_id
        teammember.role_name = role.name
        teammember.user_id = user_id
        teammembers.append(teammember)
    teammember_dao.insert_teammembers(teammembers)


def add_teamassets(body):
    teamasset_list = []
    for temp in body:
        teamasset = Teamasset()
        teamasset.team_id = temp["team_id"]
        teamasset.asset_id = temp["asset_id"]
        teamasset.asset_type = temp["asset_type"]
        teamasset.asset_category = temp.get("asset_category")
        teamasset_list.append(teamasset)
    if teamasset_list is None:
        raise BusinessException(ErrorCode.COLLECTION_IS_EMPTY)
    teamasset_dao.delete_teamAsset_byTeamId(teamasset_list[0].team_id)
    teamasset_dao.insert_teamAssets(teamasset_list)


def query_teamassets_byTeamId(team_id):
    if team_id is None:
        raise BusinessException(ErrorCode.SYS_PARAM_NULL)
    teamassets = teamasset_dao.select_teamAssets_byTeamId(team_id)
    data = to_json(teamassets)
    return data
