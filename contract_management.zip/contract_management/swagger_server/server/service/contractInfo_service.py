from swagger_server.server.dao import contract_dao
from swagger_server.common.utils import json_util as utils
from swagger_server.server.entity.models import session
from swagger_server.common.exception import business_exception as exception
import decimal
import logging
import datetime
#import xlrd
#from xlrd import xldate_as_tuple
#import flask_excel as excel
from swagger_server.common.constant.common_constant import ConmonConstant
import os
from flask import request, make_response, send_file
import requests
from swagger_server.common.utils.json_util import json2dict
import json

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def precheck_for_contract(contract):
    msg = 'precheck start date and end date...'
    logger.info(msg)
    if contract['start_date'] and contract['end_date']:
        start_date = datetime.datetime.strptime(contract['start_date'], "%Y/%m/%d")
        end_date = datetime.datetime.strptime(contract['end_date'], "%Y/%m/%d")
        rest_days = (start_date - end_date).days
        if rest_days > 0:
            msg = '合同开始时间晚于结束时间!'
            logger.error(msg)
            raise exception.InputError(msg)
    msg = 'precheck contract name...'
    logger.info(msg)
    name_contract = contract_dao.select_contract_by_name(contract['name'])
    code_contract = contract_dao.select_contract_by_code(contract['contract_code'])
    if not contract.get('id'):
        if name_contract is not None:
            msg = '合同名已存在!'
            logger.error(msg)
            raise exception.InputError(msg)
        msg = 'precheck contract code...'
        logger.info(msg)
        if code_contract is not None:
            msg = '合同编号已存在!'
            logger.error(msg)
            raise exception.InputError(msg)
    else:
        id_contract = contract_dao.select_contract_by_id(contract['id'])
        if id_contract.name != contract['name'] and name_contract is not None:
            msg = '合同名已存在!'
            logger.error(msg)
            raise exception.InputError(msg)
        msg = 'precheck contract code...'
        logger.info(msg)
        if id_contract.contract_code != contract['contract_code'] and code_contract is not None:
            msg = '合同编号已存在!'
            logger.error(msg)
            raise exception.InputError(msg)

##调用中电接口,获取乙方项目经理信息
def get_contractor_infos(type, id_list):
    if type == 'name':
        url = ConmonConstant.GET_USER_LIST_URL
        request_body = {"pageNo": 0, "pageSize": 0, "data": {"staffIds": id_list}}
    elif type == 'company':
        url = ConmonConstant.GET_COMPANY_LIST_URL
        request_body = {"pageNo": 0, "pageSize": 0, "data": {}}
    else:
        return []
    data_json = json.dumps(request_body)
    headers = ConmonConstant.POST_REQUEST_HEADERS
    resp_data = requests.post(url, data=data_json, headers=json.loads(headers)).text
    resp_dict = json2dict(resp_data)
    if resp_dict.get("success") == 1:
        return resp_dict['data']['result']
    else:
        msg = 'get contractor %s failed!' % type
        logger.error(msg)
        return []


def add_contract(contract):
    msg = 'begin precheck for contract input..'
    logger.info(msg)
    precheck_for_contract(contract)
    try:
        msg = 'begin add contract data to db..'
        logger.info(msg)
        contract_id = contract_dao.add_contract(contract)
        contract_dao.add_contract_asset(contract_id, contract['resource_id_list'], 0)
        contract_dao.add_contract_asset(contract_id, contract['cluster_id_list'], 1)
        contract_dao.add_contract_asset(contract_id, contract['system_id_list'], 2)
        contract_dao.add_contract_member(contract_id, contract['technical_support_member_list'], 0)
        contract_dao.add_contract_member(contract_id, contract['business_support_member_list'], 1)
        contract_dao.add_contract_member(contract_id, contract['onsite_support_member_list'], 2)
        session.commit()
    except Exception as e:
        session.rollback()
        session.close()
        msg = '添加合同信息失败!'
        logger.error(msg)
        raise exception.DatabaseError(msg)
    else:
        session.close()
        msg = 'add contract data to db successed!'
        logger.info(msg)


def remove_contract_by_id(id):
    try:
        contract_dao.delete_contract_by_id(id)
        session.commit()
    except exception.NotFound:
        raise
    except Exception as e:
        session.rollback()
        session.close()
        msg = '合同删除失败!'
        logger.error(msg)
        raise exception.DatabaseError(msg)
    else:
        session.close()
        msg = 'delete contract data successed!'
        logger.info(msg)


def remove_contracts_by_ids(id_list):
    try:
        for id in id_list:
            contract_dao.delete_contract_by_id(id)
        session.commit()
    except exception.NotFound:
        raise
    except Exception as e:
        session.rollback()
        session.close()
        msg = '合同删除失败!'
        logger.error(msg)
        raise exception.DatabaseError(msg)
    else:
        session.close()
        msg = 'delete contract data successed!'
        logger.info(msg)


def query_contract_by_id(id):
    try:
        logger.info("get contract  basic data...")
        contract = contract_dao.select_contract_by_id(id)
        logger.info("get contract %s assets..." % contract.name)
        resource_id_list = contract_dao.get_contract_asset(contract.id, 0)
        cluster_id_list = contract_dao.get_contract_asset(contract.id, 1)
        system_id_list = contract_dao.get_contract_asset(contract.id, 2)
        logger.info("get contract %s members..." % contract.name)
        technical_support_member_list = contract_dao.get_contract_member(contract.id, 0)
        business_support_member_list = contract_dao.get_contract_member(contract.id, 1)
        onsite_support_member_list = contract_dao.get_contract_member(contract.id, 2)
        contract_dict = utils.obj2dict(contract)
        del contract_dict['_sa_instance_state']
        contract_dict['resource_id_list'] = resource_id_list
        contract_dict['cluster_id_list'] = cluster_id_list
        contract_dict['system_id_list'] = system_id_list
        contract_dict['technical_support_member_list'] = technical_support_member_list
        contract_dict['business_support_member_list'] = business_support_member_list
        contract_dict['onsite_support_member_list'] = onsite_support_member_list
    except exception.NotFound:
        raise
    except Exception as e:
        msg = '获取合同信息失败!'
        logger.error(msg)
        raise exception.DatabaseError(msg)
    else:
        msg = 'get contract data successed! '
        logger.info(msg)
        return contract_dict


def query_contract_statistic(signed_start_date=None, signed_end_date=None, name=None):
    try:
        contracts = contract_dao.select_all_contract_list(signed_start_date, signed_end_date, name)
        contract_dict = {}
        expired_contract_count = 0
        unexpired_contract_count = 0
        expiring_contract_count = 0
        total_amount = decimal.Decimal(0)
        contract_count = 0
        for contract in contracts:
            logger.info("get contract %s date status..." % contract.name)
            contract_count += 1
            if contract.end_date:
                now_date = datetime.datetime.now().date()
                end_date = datetime.datetime.strptime(contract.end_date,"%Y/%m/%d").date()
                rest_days = (end_date - now_date).days
                if rest_days > 30:
                    unexpired_contract_count += 1
                elif rest_days < 0:
                    expired_contract_count += 1
                else:
                    expiring_contract_count += 1
            else:
                unexpired_contract_count += 1
            if contract.amount:
                total_amount = total_amount + contract.amount
        logger.info("get contract summary data..." )
        contract_dict['contract_count'] = contract_count
        contract_dict['unexpired_contract'] = unexpired_contract_count
        contract_dict['expired_contract'] = expired_contract_count
        contract_dict['expiring_contract'] = expiring_contract_count
        contract_dict['total_amount'] = total_amount
    except Exception as e:
        msg = '获取所有合同统计信息失败!'
        logger.error(msg)
        raise exception.DatabaseError(msg)
    else:
        msg = 'get all contract statistic successed! '
        logger.info(msg)
        return contract_dict


def query_contract_list(page_size=10, page_no=1, signed_start_date=None, signed_end_date=None, name=None):
    try:
        contracts = contract_dao.select_contract_list(page_size, page_no, signed_start_date, signed_end_date, name)
        contract_data_list = []
        contractor_name_list = []
        contractor_company_list = []
        contractor_id_name_dict = {}
        contractor_company_id_name_dict = {}
        for contract in contracts:
            logger.info("get contract %s date status..." % contract.name)
            if contract.end_date:
                now_date = datetime.datetime.now().date()
                end_date = datetime.datetime.strptime(contract.end_date,"%Y/%m/%d").date()
                rest_days = (end_date - now_date).days
                if rest_days > 30:
                    contract_staus = 1
                elif rest_days < 0:
                    contract_staus = -1
                else:
                    contract_staus = 0
            else:
                contract_staus = 1
                rest_days = 0
            contract_data = utils.obj2dict(contract)
            del contract_data['_sa_instance_state']
            contract_data['rest_days'] = rest_days
            contract_data['contract_staus'] = contract_staus
            if contract_data['contractor']:
                contractor_name_list.append(contract_data['contractor'])
            if contract_data['contractor_company']:
                contractor_company_list.append(contract_data['contractor_company'])
            contract_data['contractor_name'] = None
            contract_data['contractor_company_name'] = None
            contract_data_list.append(contract_data)
        if contractor_name_list:
            msg = 'get contractor id name dict'
            logger.info(msg)
            contractor_infos = get_contractor_infos('name', contractor_name_list)
            for contractor_info in contractor_infos:
                contractor_id_name_dict[contractor_info['staffId']] = contractor_info['name']
        if contractor_company_list:
            msg = 'get contractor company id name dict'
            logger.info(msg)
            contractor_infos = get_contractor_infos('company', contractor_company_list)
            for contractor_info in contractor_infos:
                contractor_company_id_name_dict[contractor_info['companyId']] = contractor_info['companyName']
        for contract_data in contract_data_list:
            if contract_data['contractor'] and contract_data['contractor'] in contractor_id_name_dict.keys():
                contract_data['contractor_name'] = contractor_id_name_dict[contract_data['contractor']]
            if contract_data['contractor_company'] and contract_data['contractor_company'] in contractor_company_id_name_dict.keys():
                contract_data['contractor_company_name'] = contractor_company_id_name_dict[contract_data['contractor_company']]
    except Exception as e:
        msg = '获取合同信息失败!'
        logger.error(msg)
        raise exception.DatabaseError(msg)
    else:
        msg = 'get all contract data successed! '
        logger.info(msg)
        return contract_data_list


def update_contract(contract):
    msg = 'begin precheck for contract input..'
    logger.info(msg)
    precheck_for_contract(contract)
    try:
        msg = 'begin add contract data to db..'
        logger.info(msg)
        contract_dao.update_contract(contract)
        contract_dao.update_contract_asset(contract['id'], contract['resource_id_list'], 0)
        contract_dao.update_contract_asset(contract['id'], contract['cluster_id_list'], 1)
        contract_dao.update_contract_asset(contract['id'], contract['system_id_list'], 2)
        contract_dao.update_contract_member(contract['id'], contract['technical_support_member_list'], 0)
        contract_dao.update_contract_member(contract['id'], contract['business_support_member_list'], 1)
        contract_dao.update_contract_member(contract['id'], contract['onsite_support_member_list'], 2)
        session.commit()
    except exception.NotFound:
        raise
    except Exception as e:
        session.rollback()
        session.close()
        msg = '更新合同失败!'
        logger.error(msg)
        raise exception.DatabaseError(msg)
    else:
        session.close()
        msg = 'update contract data to db successed!'
        logger.info(msg)


def import_contractfile_to_db(contract_file):
    logger.info("start import")
    workbook = xlrd.open_workbook(contract_file)
    Data_sheet = workbook.sheets()[0]  # 通过索引获取
    rowNum = Data_sheet.nrows  # sheet行数
    colNum = Data_sheet.ncols  # sheet列数
    if colNum != 12:
        msg = 'contract file has %s column, not correct!' % colNum
        logger.error(msg)
        raise exception.FileError(msg)
    if rowNum < 1:
        msg = 'contract file has %s row, not correct!' % rowNum
        logger.error(msg)
        raise exception.FileError(msg)
    contract_list = []
    for i in range(1, rowNum):
        rowlist = []
        for j in range(colNum):
            # rowlist.append(Data_sheet.cell_value(i, j))
            ctype = Data_sheet.cell(i, j).ctype  # 表格的数据类型
            cell = Data_sheet.cell_value(i, j)
            if ctype == 2 and cell % 1 == 0:  # 如果是整形
                cell = int(cell)
            elif ctype == 3:
                # 转成datetime对象
                date = datetime.datetime(*xldate_as_tuple(cell, 0))
                cell = date.strftime('%Y/%m/%d')
            rowlist.append(cell)
        contract_list.append(rowlist)
    try:
        for contract_data in contract_list:
            contract_dict = {}
            contract_dict['name'] = contract_data[0]
            contract_dict['contract_code'] = contract_data[1]
            contract_dict['type'] = contract_data[2]
            contract_dict['owner_company'] = contract_data[3]
            contract_dict['owner'] = contract_data[4]
            contract_dict['contractor_company'] = contract_data[5]
            contract_dict['contractor'] = contract_data[6]
            contract_dict['amount'] = contract_data[7]
            contract_dict['payment_ratio'] = contract_data[8]
            contract_dict['signed_date'] = contract_data[9]
            contract_dict['start_date'] = contract_data[10]
            contract_dict['end_date'] = contract_data[11]
            logger.info("add contract data %s to db" % contract_dict)
            contract_dao.add_contract(contract_dict)
        session.commit()
    except Exception as e:
        session.rollback()
        session.close()
        msg = 'import contract file to db failed!'
        logger.error(msg)
        raise exception.DatabaseError(msg)
    else:
        session.close()
        msg = 'import contract file to db successed!'
        logger.info(msg)


def export_db_to_contractfile(id_list):
    try:
        contract_list = []
        for id in sorted(id_list):
            contract = contract_dao.select_contract_by_id(id)
            contract_list.append(contract)
    except exception.NotFound:
        raise
    except Exception as e:
        msg = 'get contract %s data failed of %s!' % e.args
        logger.error(msg)
        raise exception.DatabaseError(msg)
    else:
        msg = 'get contract data successed! '
        logger.info(msg)
        msg = 'begin to exoport contract data to contract file.. '
        logger.info(msg)
        return excel.make_response_from_query_sets(
            contract_list,
            column_names=[
                'name',
                'contract_code',
                'type',
                'owner_company',
                'owner',
                'contractor_company',
                'contractor',
                'amount',
                'payment_ratio',
                'signed_date',
                'start_date',
                'end_date'
            ],
            file_type='xlsx',
            status=200,
            file_name='contract.xlsx'
        )


def upload_to_host():
    file = request.files['file']
    filename = file.filename
    fileinfo = os.path.splitext(filename)
    # 文件格式检查
    ALLOWED_EXTENSIONS = ['.xls', '.xlsx']
    if fileinfo[1] not in ALLOWED_EXTENSIONS:
        msg = 'contract file %s not excel!' % filename
        logger.error(msg)
        raise exception.TypeError(msg)
    # 文件名拼接
    filename_before_point = fileinfo[0]
    filename_format = fileinfo[1]
    filename_complete = filename_before_point + datetime.datetime.now().strftime("%Y%m%d%H%M%S") + filename_format
    # 文件保存
    file_dir = ConmonConstant.FILE_DIR
    if not os.path.exists(file_dir):
        os.makedirs(file_dir)
    file.save(os.path.join(file_dir, filename_complete))


def download_contract_templet():
    file_path = ConmonConstant.TEMPET_FILE_DIR + ConmonConstant.TEMPET_FILE_NAME
    file_name = ConmonConstant.TEMPET_FILE_NAME
    response = make_response(send_file(file_path))
    header = "attachment; filename=%s;" % (file_name)
    response.headers["Content-Disposition"] = header
    return response
