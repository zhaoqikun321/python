class TeamVo:
    def __init__(self):
        self.id=None
        self.name = None
        self.des = None
        self.display_order=None

class TeamInfoVo:
    def __init__(self):
        self.id=None
        self.des = None
        self.user_name = None
        self.team_userNum=None
        self.email=None
        self.tel=None

