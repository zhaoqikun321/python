

class TeammemberVo:

    def __init__(self):
        self.user_name = None
        self.tel = None
        self.email = None
        self.department = None
        self.role_name = None
