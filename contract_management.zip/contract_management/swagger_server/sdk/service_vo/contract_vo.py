class ContractVo:

    def __init__(self):
        self.id = None
        self.contract_code = None
        self.name = None
        self.type = None
        self.owner = None
        self.ower_company = None
        self.contractor = None
        self.contractor_company = None
        self.signed_date = None
        self.start_date = None
        self.end_date = None
        self.amount = None
        self.payment_ratio = None
        self.asset_id_list = None
        self.technical_support_staff_list = None
        self.business_support_staff_list = None
        self.onsite_support_staff_list = None