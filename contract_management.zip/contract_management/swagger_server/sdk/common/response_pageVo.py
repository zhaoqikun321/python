
class ResponsePageVo:

    #totalSize:数据结果总条数

    #result:查询后的结果集

    def __init__(self,total_size,result):
        self.total_size=total_size
        self.result=result