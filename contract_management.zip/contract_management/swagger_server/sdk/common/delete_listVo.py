

class DeleteIdListVo:

    #del_id_list:删除id的列表

    def __init__(self,del_id_list):
        self.del_id_list=del_id_list
