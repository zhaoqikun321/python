from flask import Response
from werkzeug.datastructures import Headers
from swagger_server.common.utils.json_util import dict2json


class FailureJSONResponse(Response):
    def __init__(self, error_info):
        if hasattr(error_info, 'message'):
            dict_data = dict(success='0', error_code="10000000", error_msg=error_info.message, error_level="error")
        else:
            dict_data = dict(success='0', error_code="10000000", error_msg="系统错误", error_level="error")
        if error_info.__class__.__name__ == "BusinessException":
            dict_data = dict(success='0', error_code=error_info.error_code, error_msg=error_info.error_msg,
                         error_level=error_info.error_level)
        result = dict2json(dict_data)
        Response.__init__(self, result, mimetype='application/json')


class SucessJSONResponse(Response):
    def __init__(self, data):
        dict_data = dict(success='1', data=data)
        result = dict2json(dict_data)
        Response.__init__(self, result, mimetype='application/json')


