
class RequestPageVo:

    #page_size:每一页的行数

    #page_no:查询页号

    #data:查询列表条件集
    
    def __init__(self,page_size,page_no,data):
        self.page_size=page_size
        self.page_no=page_no
        self.data=data