
class ErrorCode:
    #平台通用异常码以10000开头
    SYS_ERROR=("100000000", "系统错误","error")
    SYS_DB_OPER_ERROR=("100000001", "数据库操作失败","error")
    SYS_PARAM_NULL=("100000002", "关键参数为空","warn")
    UNKNOWN_ERROR=("100000003", "未知错误,请联系管理员","warn")
    OPERATOR_ERROR=("100000004", "对象操作异常","error")
    TOKEN_ERROR=("100000005", "认证信息验证失败","error")
    SERVICE_NOT_STARTED=("100000006", "调用服务未启动","error")
    JOB_NOT_STARTED=("100000007", "定时任务服务未启动","error")
    ERROR_ES_PARAM=("100000008", "ES操作语法错误","error")
    ERROR_DATE_FORMAT=("100000009", "日期或时间格式不支持,请重新输入","error")
    CONTENT_IS_EMPTY=("1000000010", "输入内容为空","error")
    QUERY_OPER_ERROR=("1000000011", "数据查询失败","error")
    COLLECTION_IS_EMPTY=("1000000012", "集合为空","error")
    ROLENAME_IS_EMPTY=("1000000013", "角色名为空","error")
    TEAM_IS_EMPTY=("1000000014", "运维组不存在","error")
    TEAM_NAME_REPEAT=("1000000015", "组名已存在","error")
    ROLE_NAME_REPEAT=("1000000016", "组内角色名已存在","error")
    REQUEST_EXTERNAL_INTERFACE_FAILED=("1000000017", "请求外部接口失败","error")
    USER_NOT_EXISTS=("1000000018", "人员被删除,请刷新页面","info")
    USER_IS_EXISTS=("1000000019", "人员已在运维组,请勿重复添加","info")

#平台通用异常码end