
class BusinessException(Exception):

    def __init__(self, error_info):
        # 异常码
        self.error_code = error_info[0]
        # 异常信息
        self.error_msg = error_info[1]
        # 异常等级
        self.error_level = error_info[2]

class DatabaseError(Exception):
    def __init__(self, message):
         self.message = message

class TypeError(Exception):
    def __init__(self, message):
         self.message = message

class NotFound(Exception):
    def __init__(self, message):
         self.message = message

class FileError(Exception):
    def __init__(self, message):
         self.message = message

class InputError(Exception):
    def __init__(self, message):
         self.message = message
