import json
import logging
import time
import requests
from swagger_server.common.constant.common_constant import ConmonConstant
from swagger_server.common.exception.business_exception import BusinessException
from swagger_server.common.exception.error_code import ErrorCode
from swagger_server.common.utils.json_util import json2dict
from swagger_server.server.dao import teammember_dao

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

#获取微秒级时间戳,13位
def get_timestamp():
    t = time.time()
    millisecond=int(round(t * 1000))
    return millisecond

#访问中电接口获取用户信息
def get_user_byId(user_id):
    user_id = str(user_id)
    url = ConmonConstant.GET_USER_URL + user_id
    resp_data = requests.get(url).text
    if resp_data is None:
        raise BusinessException(ErrorCode.REQUEST_EXTERNAL_INTERFACE_FAILED)
    user_dict = json2dict(resp_data)
    return  user_dict

#访问中电接口获取用户信息列表
def get_userInfo_list(user_idList):
    url = ConmonConstant.GET_USER_LIST_URL
    request_body = {"pageNo": 0, "pageSize": 0, "data": {"staffIds": user_idList}}
    data_json = json.dumps(request_body)
    headers = ConmonConstant.POST_REQUEST_HEADERS
    resp_data = requests.post(url, data=data_json, headers=json.loads(headers)).text
    if resp_data is None:
        raise BusinessException(ErrorCode.REQUEST_EXTERNAL_INTERFACE_FAILED)
    resp_dict = json2dict(resp_data)
    return resp_dict



# 获取运维组人数
def get_teammember_count(Id):
    teammembers = teammember_dao.select_teammember_byTeamId(Id)
    # 获取user_idList
    user_idList = []
    for teammember in teammembers:
        if teammember.user_id is not None:
            user_idList.append(teammember.user_id)
    if len(user_idList) == 0:
        return 0
    # 调用中电接口获取用户列表数据
    resp_dict = get_userInfo_list(user_idList)
    if resp_dict.get("success") == 0:
        logger.error(resp_dict.get("message"))
        raise BusinessException(ErrorCode.REQUEST_EXTERNAL_INTERFACE_FAILED)
    user_list = resp_dict["data"]["result"]
    user_count=0
    for teammember in teammembers:
        for user in user_list:
            if teammember.user_id == user["staffId"]:
                user_count+=1
                break
    return user_count