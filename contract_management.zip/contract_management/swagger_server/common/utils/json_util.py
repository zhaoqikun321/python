import json
import decimal

def to_json(all_vendors):
    v = [ ven.dobule_to_dict() for ven in all_vendors ]
    return v

def obj2json(obj):
    dict_data=obj.__dict__
    json_data=json.dumps(dict_data,sort_keys=False,indent=4,ensure_ascii=False)
    return json_data

def json2obj(str,cls):
    dict_data=json.loads(str)
    obj=cls()
    obj.__dict__=dict_data
    return obj

def json2dict(str):
    dict_data=json.loads(str)
    return dict_data

def dict2json(dict_data):
    json_data=json.dumps(dict_data,sort_keys=False,indent=4,ensure_ascii=False,cls=DecimalEncoder)
    return json_data

def dict2obj(dict_data,cls):
    obj=cls()
    obj.__dict__=dict_data
    return obj

def obj2dict(obj):
    dict_data=obj.__dict__
    return dict_data

def to_dict(obj):
    v = obj.dobule_to_dict()
    return v

class DecimalEncoder(json.JSONEncoder):

    def default(self, o):

        if isinstance(o, decimal.Decimal):
            return float(o)

        super(DecimalEncoder, self).default(o)


