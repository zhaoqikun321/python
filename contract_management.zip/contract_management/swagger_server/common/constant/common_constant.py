import configparser
import platform

class ConmonConstant:
    # 合约模板文件名
    TEMPET_FILE_NAME = "contract_templet.xlsx"
    # 合约模板文件保存路径
    TEMPET_FILE_DIR = "D:/"
    # 用户上传合约保存路径
    FILE_DIR = "D:/"

    windows_path="D://PythonProject-2//contract_management//swagger_server//common//constant//foreign_url.ini"
    linux_path="/etc/contract/foreign_url.ini"
    cf = configparser.ConfigParser()
    if (platform.system() == 'Windows'):
        cf.read(windows_path)
    else:
        cf.read(linux_path)
    #南瑞环境用户接口url
    GET_USER_URL = cf.get("DEFAULT", "GET_USER_URL")
    GET_USER_LIST_URL = cf.get("DEFAULT", "GET_USER_LIST_URL")
    POST_REQUEST_HEADERS=cf.get("DEFAULT", "POST_REQUEST_HEADERS")

    COMPANY_URL = cf.get("DEFAULT", "COMPANY_URL")
    GET_COMPANY_LIST_URL = cf.get("DEFAULT", "GET_COMPANY_LIST_URL")
    HEADERS =cf.get("DEFAULT", "HEADERS")


