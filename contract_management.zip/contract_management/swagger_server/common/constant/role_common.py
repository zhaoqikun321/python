class RoleConstant:
    # 预制角色名
    TEAM_LEADER = "组长"
    DEPUTY_TEAM_LEADER="副组长"
    TECHNOLOGICAL_BACKBONE="技术骨干"
    GENERAL_TECHNOLOGY_OPERATION="普通技术运维"
    BUSINESS_OPERATION="业务运维"

    #预制展示顺序
    DISPLAY_ONE=1
    DISPLAY_TWO=2
    DISPLAY_THREE=3
    DISPLAY_FORUE=4
    DISPLAY_FIVE=5
