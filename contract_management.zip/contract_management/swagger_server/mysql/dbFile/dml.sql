-- dml
INSERT `team` (id,name,des) VALUE (1,"电力运维一组","负责运维电力系统");
INSERT `team` (id,name,des) VALUE (2,"主机运维A组","负责运维主机");
delete from `team` where id = 1;
delete from `team` where id = 2;
truncate `team`;



INSERT `teammember` (id,team_id,role_id,user_id) VALUE (1,1,1,474);
INSERT `teammember` (id,team_id,role_id,user_id) VALUE (2,1,2,30475);
INSERT `teammember` (id,team_id,role_id,user_id) VALUE (3,1,3,null);
INSERT `teammember` (id,team_id,role_id,user_id) VALUE (4,1,4,null);
INSERT `teammember` (id,team_id,role_id,user_id) VALUE (5,1,5,null);
INSERT `teammember` (id,team_id,role_id,user_id) VALUE (6,2,6,474);
INSERT `teammember` (id,team_id,role_id,user_id) VALUE (7,2,7,30475);
INSERT `teammember` (id,team_id,role_id,user_id) VALUE (8,2,8,null);
INSERT `teammember` (id,team_id,role_id,user_id) VALUE (9,2,9,null);
INSERT `teammember` (id,team_id,role_id,user_id) VALUE (10,2,10,null);
delete from `teammember` where id = 1;
delete from `teammember` where id = 2;
delete from `teammember` where id = 3;
delete from `teammember` where id = 4;
delete from `teammember` where id = 5;
delete from `teammember` where id = 6;
delete from `teammember` where id = 7;
delete from `teammember` where id = 8;
delete from `teammember` where id = 9;
delete from `teammember` where id = 10;
truncate `teammember`;



INSERT `teamasset` (id,team_id,asset_id,asset_type,asset_category) VALUE (1,1,0,0,1);
INSERT `teamasset` (id,team_id,asset_id,asset_type,asset_category) VALUE (2,2,1,1,null);
INSERT `teamasset` (id,team_id,asset_id,asset_type,asset_category) VALUE (3,3,2,2,null);
delete from `teamasset` where id = 1;
delete from `teamasset` where id = 2;
delete from `teamasset` where id = 3;
truncate `teamasset`;




INSERT `role` (id,name) VALUE (1,"组长");
INSERT `role` (id,name) VALUE (2,"副组长");
INSERT `role` (id,name) VALUE (3,"技术骨干");
INSERT `role` (id,name) VALUE (4,"普通技术运维");
INSERT `role` (id,name) VALUE (5,"业务运维");
INSERT `role` (id,name) VALUE (6,"组长");
INSERT `role` (id,name) VALUE (7,"副组长");
INSERT `role` (id,name) VALUE (8,"技术骨干");
INSERT `role` (id,name) VALUE (9,"普通技术运维");
INSERT `role` (id,name) VALUE (10,"业务运维");
delete from `role` where id = 1;
delete from `role` where id = 2;
delete from `role` where id = 3;
delete from `role` where id = 4;
delete from `role` where id = 5;
delete from `role` where id = 6;
delete from `role` where id = 7;
delete from `role` where id = 8;
delete from `role` where id = 9;
delete from `role` where id = 10;
truncate `role`;




INSERT INTO contract_management.contract (id, contract_code, name, type, owner, owner_company, contractor, contractor_company, signed_date, start_date, end_date, amount, payment_ratio) VALUES (5, 'contract_code', 'name', 'type', 6, 3, 1, 4, '2020/01/01', '2020/01/01', '2020/02/01', 5.0000, 40.0000);
INSERT INTO contract_management.contract (id, contract_code, name, type, owner, owner_company, contractor, contractor_company, signed_date, start_date, end_date, amount, payment_ratio) VALUES (14, 'contract_code', 'name', 'type', 6, 3, 1, 4, '2020/02/01', '2020/02/01', '2020/03/01', 5.0000, 50.0000);
INSERT INTO contract_management.contract (id, contract_code, name, type, owner, owner_company, contractor, contractor_company, signed_date, start_date, end_date, amount, payment_ratio) VALUES (15, '2020', '宁夏互联网大区数据中心', '运维合同', 1, 1, 5, 3, '2020/04/09', '2020/05/01', '2020/06/01', 500.1000, 100.0000);
INSERT INTO contract_management.contract (id, contract_code, name, type, owner, owner_company, contractor, contractor_company, signed_date, start_date, end_date, amount, payment_ratio) VALUES (16, '2020', '宁夏互联网大区数据中心', '运维合同', 2, 1, 6, 4, '2020/04/09', '2020/05/01', '', 500.1000, 100.0000);
INSERT INTO contract_management.contract (id, contract_code, name, type, owner, owner_company, contractor, contractor_company, signed_date, start_date, end_date, amount, payment_ratio) VALUES (17, '2020', '宁夏互联网大区数据中心', '运维合同', 1, 1, 5, 3, '2020/04/09', '2020/05/01', '', 500.1000, 100.0000);
INSERT INTO contract_management.contract (id, contract_code, name, type, owner, owner_company, contractor, contractor_company, signed_date, start_date, end_date, amount, payment_ratio) VALUES (18, '2020', '宁夏互联网大区数据中心', '运维合同', 2, 1, 6, 4, '2020/04/09', '2020/05/01', '', 500.1000, 100.0000);

INSERT INTO contract_management.contract (id, contract_code, name, type, owner, owner_company, contractor, contractor_company, signed_date, start_date, end_date, amount, payment_ratio) VALUES (20, '2020', '宁夏互联网大区数据中心', '运维合同', 2, 1, 6, 4, '2020/04/09', '2020/05/01', '', 500.1000, 100.0000);
INSERT INTO contract_management.contract (id, contract_code, name, type, owner, owner_company, contractor, contractor_company, signed_date, start_date, end_date, amount, payment_ratio) VALUES (21, '2020', '宁夏互联网大区数据中心', '运维合同', 2, 1, 6, 4, '2020/04/09', '2020/05/01', '', 500.1000, 100.0000);
INSERT INTO contract_management.contract (id, contract_code, name, type, owner, owner_company, contractor, contractor_company, signed_date, start_date, end_date, amount, payment_ratio) VALUES (22, '2020', '宁夏互联网大区数据中心', '运维合同', 2, 1, 6, 4, '2020/04/09', '2020/05/01', '', 500.1000, 100.0000);
INSERT INTO contract_management.contract (id, contract_code, name, type, owner, owner_company, contractor, contractor_company, signed_date, start_date, end_date, amount, payment_ratio) VALUES (23, '2020', '宁夏互联网大区数据中心', '运维合同', 2, 1, 6, 4, '2020/04/09', '2020/05/01', '', 500.1000, 100.0000);
INSERT INTO contract_management.contract (id, contract_code, name, type, owner, owner_company, contractor, contractor_company, signed_date, start_date, end_date, amount, payment_ratio) VALUES (24, '2020', '宁夏互联网大区数据中心', '运维合同', 2, 1, 6, 4, '2020/04/09', '2020/05/01', '', 500.1000, 100.0000);
INSERT INTO contract_management.contract (id, contract_code, name, type, owner, owner_company, contractor, contractor_company, signed_date, start_date, end_date, amount, payment_ratio) VALUES (25, '2020', '宁夏互联网大区数据中心', '运维合同', 2, 1, 6, 4, '2020/04/09', '2020/05/01', '', 500.1000, 100.0000);
INSERT INTO contract_management.contract (id, contract_code, name, type, owner, owner_company, contractor, contractor_company, signed_date, start_date, end_date, amount, payment_ratio) VALUES (26, '2020', '宁夏互联网大区数据中心', '运维合同', 2, 1, 6, 4, '2020/04/09', '2020/05/01', '', 500.1000, 100.0000);
INSERT INTO contract_management.contract (id, contract_code, name, type, owner, owner_company, contractor, contractor_company, signed_date, start_date, end_date, amount, payment_ratio) VALUES (27, '2020', '宁夏互联网大区数据中心', '运维合同', 2, 1, 6, 4, '2020/04/09', '2020/05/01', '', 500.1000, 100.0000);
delete from `contract` where id = 5;
delete from `contract` where id = 14;
delete from `contract` where id = 15;
delete from `contract` where id = 16;
delete from `contract` where id = 17;
delete from `contract` where id = 18;
