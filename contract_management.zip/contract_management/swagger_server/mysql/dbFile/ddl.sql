

DROP TABLE IF EXISTS `team`;
CREATE TABLE IF NOT EXISTS `team` (
  id               BIGINT(32) AUTO_INCREMENT,
  name             VARCHAR(20) COMMENT "运维团队名称",
  des              VARCHAR(100) COMMENT "描述",
  display_order    BIGINT(32) COMMENT "运维组展示顺序",
  PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `role`;
CREATE TABLE IF NOT EXISTS `role` (
  id               BIGINT(32) AUTO_INCREMENT,
  name             VARCHAR(20) COMMENT "角色名称",
  display_order    BIGINT(32) COMMENT "角色展示顺序",
  PRIMARY KEY (id)) ENGINE=InnoDB  DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `teammember`;
CREATE TABLE IF NOT EXISTS `teammember` (
  id               BIGINT(32) AUTO_INCREMENT,
  team_id          BIGINT(32) COMMENT "运维团队表id",
  role_id          BIGINT(32) COMMENT "角色表id",
  role_name        VARCHAR(20) COMMENT"角色名称",
  user_id          BIGINT(32) COMMENT "用户表id",
  display_order    BIGINT(32) COMMENT "角色展示顺序",
  PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER table `teammember` add INDEX `index_display` (`team_id`,`display_order`);

DROP TABLE IF EXISTS `teamasset`;
CREATE TABLE IF NOT EXISTS `teamasset` (
  id               BIGINT(32) AUTO_INCREMENT,
  team_id          BIGINT(32) COMMENT "运维团队id",
  asset_id         BIGINT(32) COMMENT "资产表id",
  asset_type       BIGINT(32) COMMENT "资产类型,0资源,1平台系统,2业务系统",
  asset_category   BIGINT(32) COMMENT "资源中资产类型所属类目",
  PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER table `teamasset` add INDEX `index_team_id` (`team_id`);


DROP TABLE IF EXISTS `contract`;
CREATE TABLE IF NOT EXISTS `contract` (
  id               BIGINT(32) AUTO_INCREMENT,
  contract_code    VARCHAR(40) COMMENT "合同编号",
  name             VARCHAR(40) COMMENT "合同名称",
  type             VARCHAR(64) COMMENT "合同类型",
  owner            INT(64) COMMENT "甲方项目经理",
  owner_company     BIGINT(32) COMMENT "甲方单位",
  owner_signer     BIGINT(32) COMMENT "甲方合同签署人",
  owner_bank       VARCHAR(40) COMMENT "甲方开户银行",
  owner_bank_account VARCHAR(20) COMMENT "甲方银行账号",
  contractor       BIGINT(32) COMMENT "乙方项目经理",
  contractor_company BIGINT(32) COMMENT "乙方单位",
  contractor_signer BIGINT(32) COMMENT "乙方合同签署人",
  contractor_bank  VARCHAR(40) COMMENT "乙方开户银行",
  contractor_bank_account VARCHAR(20) COMMENT "乙方银行账号",
  signed_date      VARCHAR(64) COMMENT "签订日期",
  start_date       VARCHAR(64) COMMENT "起始日期",
  end_date         VARCHAR(64) COMMENT "结束日期",
  amount           DECIMAL(8,2) COMMENT "合同金额",
  payment_ratio    FLOAT(5,2) COMMENT "付款比例",
  PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `contractasset`;
CREATE TABLE IF NOT EXISTS `contractasset` (
  id               BIGINT(32) AUTO_INCREMENT,
  contract_id      BIGINT(32) COMMENT "合约表id",
  asset_id         BIGINT(32) COMMENT "资产表id",
  asset_type       BIGINT(32) COMMENT "资产类型,0资源,1平台系统,2业务系统",
  asset_category   BIGINT(32) COMMENT "资源中资产类型所属类目",
  PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `contractmember`;
CREATE TABLE IF NOT EXISTS `contractmember` (
  id               BIGINT(32) AUTO_INCREMENT,
  contract_id      BIGINT(32) COMMENT "合约表id",
  user_id          BIGINT(32) COMMENT "用户表id",
  user_type        BIGINT(32) COMMENT "用户类型,0,echnical_support，1,business_support，2,resident_support",
  PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=utf8;

