import datetime

def inc(x):
    return x + 1
